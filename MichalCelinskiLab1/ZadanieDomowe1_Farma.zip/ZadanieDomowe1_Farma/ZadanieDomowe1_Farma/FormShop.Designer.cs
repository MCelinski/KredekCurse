﻿
namespace ZadanieDomowe1_Farma
{
    partial class FormShop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelShopJuice1 = new System.Windows.Forms.Label();
            this.pictureBoxShopJuice1 = new System.Windows.Forms.PictureBox();
            this.buttonShopBuyJuice1 = new System.Windows.Forms.Button();
            this.buttonShopBuyJuice2 = new System.Windows.Forms.Button();
            this.pictureBoxShopJuice2 = new System.Windows.Forms.PictureBox();
            this.labelShopJuice2 = new System.Windows.Forms.Label();
            this.buttonShopJuice3 = new System.Windows.Forms.Button();
            this.labelShopJuice3 = new System.Windows.Forms.Label();
            this.pictureBoxShopJuice3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxShopShelve1 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelShopAntidotum = new System.Windows.Forms.Label();
            this.pictureBoxShopAntidotum = new System.Windows.Forms.PictureBox();
            this.buttonShopAntidotum = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxShopJuice1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxShopJuice2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxShopJuice3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxShopShelve1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxShopAntidotum)).BeginInit();
            this.SuspendLayout();
            // 
            // labelShopJuice1
            // 
            this.labelShopJuice1.AutoSize = true;
            this.labelShopJuice1.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelShopJuice1.Location = new System.Drawing.Point(196, 27);
            this.labelShopJuice1.Name = "labelShopJuice1";
            this.labelShopJuice1.Size = new System.Drawing.Size(372, 42);
            this.labelShopJuice1.TabIndex = 0;
            this.labelShopJuice1.Text = "Nawóz do Marchewek ";
            // 
            // pictureBoxShopJuice1
            // 
            this.pictureBoxShopJuice1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxShopJuice1.Image = global::ZadanieDomowe1_Farma.Properties.Resources._6769018_carrot_juice_carrot_png_download;
            this.pictureBoxShopJuice1.Location = new System.Drawing.Point(24, 27);
            this.pictureBoxShopJuice1.Name = "pictureBoxShopJuice1";
            this.pictureBoxShopJuice1.Size = new System.Drawing.Size(166, 150);
            this.pictureBoxShopJuice1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxShopJuice1.TabIndex = 1;
            this.pictureBoxShopJuice1.TabStop = false;
            this.pictureBoxShopJuice1.Click += new System.EventHandler(this.pictureBoxShopJuice1_Click);
            // 
            // buttonShopBuyJuice1
            // 
            this.buttonShopBuyJuice1.Location = new System.Drawing.Point(279, 85);
            this.buttonShopBuyJuice1.Name = "buttonShopBuyJuice1";
            this.buttonShopBuyJuice1.Size = new System.Drawing.Size(173, 77);
            this.buttonShopBuyJuice1.TabIndex = 2;
            this.buttonShopBuyJuice1.Text = "kup za 5 LVL";
            this.buttonShopBuyJuice1.UseVisualStyleBackColor = true;
            this.buttonShopBuyJuice1.Click += new System.EventHandler(this.buttonShopBuyJuice1_Click);
            // 
            // buttonShopBuyJuice2
            // 
            this.buttonShopBuyJuice2.Location = new System.Drawing.Point(840, 85);
            this.buttonShopBuyJuice2.Name = "buttonShopBuyJuice2";
            this.buttonShopBuyJuice2.Size = new System.Drawing.Size(173, 77);
            this.buttonShopBuyJuice2.TabIndex = 5;
            this.buttonShopBuyJuice2.Text = "kup za 10 LVL";
            this.buttonShopBuyJuice2.UseVisualStyleBackColor = true;
            this.buttonShopBuyJuice2.Click += new System.EventHandler(this.buttonShopBuyJuice2_Click);
            // 
            // pictureBoxShopJuice2
            // 
            this.pictureBoxShopJuice2.Image = global::ZadanieDomowe1_Farma.Properties.Resources.nawoz_doziemniakow;
            this.pictureBoxShopJuice2.Location = new System.Drawing.Point(566, 27);
            this.pictureBoxShopJuice2.Name = "pictureBoxShopJuice2";
            this.pictureBoxShopJuice2.Size = new System.Drawing.Size(136, 139);
            this.pictureBoxShopJuice2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxShopJuice2.TabIndex = 4;
            this.pictureBoxShopJuice2.TabStop = false;
            this.pictureBoxShopJuice2.Click += new System.EventHandler(this.pictureBoxShopJuice2_Click);
            // 
            // labelShopJuice2
            // 
            this.labelShopJuice2.AutoSize = true;
            this.labelShopJuice2.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelShopJuice2.Location = new System.Drawing.Point(718, 27);
            this.labelShopJuice2.Name = "labelShopJuice2";
            this.labelShopJuice2.Size = new System.Drawing.Size(371, 42);
            this.labelShopJuice2.TabIndex = 3;
            this.labelShopJuice2.Text = "Nawóz do Ziemniaków";
            // 
            // buttonShopJuice3
            // 
            this.buttonShopJuice3.Location = new System.Drawing.Point(279, 285);
            this.buttonShopJuice3.Name = "buttonShopJuice3";
            this.buttonShopJuice3.Size = new System.Drawing.Size(173, 83);
            this.buttonShopJuice3.TabIndex = 6;
            this.buttonShopJuice3.Text = "Kup za 25 LVL";
            this.buttonShopJuice3.UseVisualStyleBackColor = true;
            this.buttonShopJuice3.Click += new System.EventHandler(this.buttonShopJuice3_Click);
            // 
            // labelShopJuice3
            // 
            this.labelShopJuice3.AutoSize = true;
            this.labelShopJuice3.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelShopJuice3.Location = new System.Drawing.Point(196, 239);
            this.labelShopJuice3.Name = "labelShopJuice3";
            this.labelShopJuice3.Size = new System.Drawing.Size(350, 42);
            this.labelShopJuice3.TabIndex = 7;
            this.labelShopJuice3.Text = "Nawóz do Truskawek";
            // 
            // pictureBoxShopJuice3
            // 
            this.pictureBoxShopJuice3.Image = global::ZadanieDomowe1_Farma.Properties.Resources._126_K_truskawka_350_g_wiz_od;
            this.pictureBoxShopJuice3.Location = new System.Drawing.Point(12, 228);
            this.pictureBoxShopJuice3.Name = "pictureBoxShopJuice3";
            this.pictureBoxShopJuice3.Size = new System.Drawing.Size(178, 152);
            this.pictureBoxShopJuice3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxShopJuice3.TabIndex = 8;
            this.pictureBoxShopJuice3.TabStop = false;
            this.pictureBoxShopJuice3.Click += new System.EventHandler(this.pictureBoxShopJuice3_Click);
            // 
            // pictureBoxShopShelve1
            // 
            this.pictureBoxShopShelve1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxShopShelve1.Image = global::ZadanieDomowe1_Farma.Properties.Resources.unnamed__1_;
            this.pictureBoxShopShelve1.Location = new System.Drawing.Point(12, 27);
            this.pictureBoxShopShelve1.Name = "pictureBoxShopShelve1";
            this.pictureBoxShopShelve1.Size = new System.Drawing.Size(1104, 210);
            this.pictureBoxShopShelve1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxShopShelve1.TabIndex = 9;
            this.pictureBoxShopShelve1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ZadanieDomowe1_Farma.Properties.Resources.unnamed__1_1;
            this.pictureBox1.Location = new System.Drawing.Point(-20, 228);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1125, 227);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // labelShopAntidotum
            // 
            this.labelShopAntidotum.AutoSize = true;
            this.labelShopAntidotum.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelShopAntidotum.Location = new System.Drawing.Point(718, 237);
            this.labelShopAntidotum.Name = "labelShopAntidotum";
            this.labelShopAntidotum.Size = new System.Drawing.Size(387, 45);
            this.labelShopAntidotum.TabIndex = 11;
            this.labelShopAntidotum.Text = "środek mszycobójczy ";
            // 
            // pictureBoxShopAntidotum
            // 
            this.pictureBoxShopAntidotum.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxShopAntidotum.Image = global::ZadanieDomowe1_Farma.Properties.Resources.mszyce;
            this.pictureBoxShopAntidotum.Location = new System.Drawing.Point(566, 228);
            this.pictureBoxShopAntidotum.Name = "pictureBoxShopAntidotum";
            this.pictureBoxShopAntidotum.Size = new System.Drawing.Size(136, 152);
            this.pictureBoxShopAntidotum.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxShopAntidotum.TabIndex = 12;
            this.pictureBoxShopAntidotum.TabStop = false;
            this.pictureBoxShopAntidotum.Click += new System.EventHandler(this.pictureBoxShopAntidotum_Click);
            // 
            // buttonShopAntidotum
            // 
            this.buttonShopAntidotum.Location = new System.Drawing.Point(840, 285);
            this.buttonShopAntidotum.Name = "buttonShopAntidotum";
            this.buttonShopAntidotum.Size = new System.Drawing.Size(173, 83);
            this.buttonShopAntidotum.TabIndex = 14;
            this.buttonShopAntidotum.Text = "KUP za 10 LVL";
            this.buttonShopAntidotum.UseVisualStyleBackColor = true;
            this.buttonShopAntidotum.Click += new System.EventHandler(this.buttonShopAntidotum_Click);
            // 
            // FormShop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1107, 497);
            this.Controls.Add(this.buttonShopAntidotum);
            this.Controls.Add(this.labelShopAntidotum);
            this.Controls.Add(this.pictureBoxShopAntidotum);
            this.Controls.Add(this.pictureBoxShopJuice3);
            this.Controls.Add(this.labelShopJuice3);
            this.Controls.Add(this.buttonShopJuice3);
            this.Controls.Add(this.buttonShopBuyJuice2);
            this.Controls.Add(this.pictureBoxShopJuice2);
            this.Controls.Add(this.labelShopJuice2);
            this.Controls.Add(this.buttonShopBuyJuice1);
            this.Controls.Add(this.pictureBoxShopJuice1);
            this.Controls.Add(this.labelShopJuice1);
            this.Controls.Add(this.pictureBoxShopShelve1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "FormShop";
            this.Text = "SKLEP";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxShopJuice1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxShopJuice2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxShopJuice3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxShopShelve1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxShopAntidotum)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelShopJuice1;
        private System.Windows.Forms.PictureBox pictureBoxShopJuice1;
        private System.Windows.Forms.Button buttonShopBuyJuice1;
        private System.Windows.Forms.Button buttonShopBuyJuice2;
        private System.Windows.Forms.PictureBox pictureBoxShopJuice2;
        private System.Windows.Forms.Label labelShopJuice2;
        private System.Windows.Forms.Button buttonShopJuice3;
        private System.Windows.Forms.Label labelShopJuice3;
        private System.Windows.Forms.PictureBox pictureBoxShopJuice3;
        private System.Windows.Forms.PictureBox pictureBoxShopShelve1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelShopAntidotum;
        private System.Windows.Forms.PictureBox pictureBoxShopAntidotum;
        private System.Windows.Forms.Button buttonShopAntidotum;
    }
}